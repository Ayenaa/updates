﻿using Bank.Models.Entities;
//using BankLoanManagementSystem.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;


namespace Bank.Data
{
    public class BankContext : DbContext
    {


        public BankContext(DbContextOptions<BankContext> options)
            : base(options)
        {
        }


        public DbSet<Customer> Customers { get; set; }
        public DbSet<LoanProduct> LoanProducts { get; set; }
        public DbSet<LoanApplication> LoanApplications { get; set; }
        public DbSet<Repayment> Repayments { get; set; }

    }
}
