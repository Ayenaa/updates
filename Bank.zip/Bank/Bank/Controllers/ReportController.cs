﻿using Bank.Services;
using Microsoft.AspNetCore.Mvc;

namespace Bank.Controllers
{
    public class ReportController : Controller
    {
        private readonly ReportService _reportService;

        public ReportController(ReportService reportService)
        {
            _reportService = reportService;
        }

        public IActionResult report()
        {
            return View();
        }
        public IActionResult LoanReport()
        {
            ViewBag.LoanReport = _reportService.GenerateLoanReport();
            return PartialView("_LoanReport");
        }

        public IActionResult RepaymentReport()
        {
            ViewBag.RepaymentReport = _reportService.GenerateRepaymentReport();
            return PartialView("_RepaymentReport");
        }

        public IActionResult OutstandingLoansReport()
        {
            ViewBag.OutstandingLoansReport = _reportService.GenerateOutstandingLoansReport();
            return PartialView("_OutstandingReport");
        }
    }

}
