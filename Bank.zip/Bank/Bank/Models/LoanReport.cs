﻿namespace Bank.Models
{
    public class LoanReport
    {
        public int ApplicationId { get; set; }
        public string CustomerName { get; set; }
        public string LoanType { get; set; }
        public decimal LoanAmount { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string ApprovalStatus { get; set; }
    }
    public class RepaymentReport
    {
        public int RepaymentId { get; set; }
        public string CustomerName { get; set; }
        public decimal AmountDue { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string PaymentStatus { get; set; }
    }
    public class OutstandingLoansReport
    {
        public int ApplicationId { get; set; }
        public string CustomerName { get; set; }
        public string LoanType { get; set; }
        public decimal OutstandingBalance { get; set; }
    }


}
