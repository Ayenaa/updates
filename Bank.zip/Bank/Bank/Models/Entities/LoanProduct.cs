﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Bank.Models.Entities;

namespace Bank.Models.Entities
{
    public class LoanProduct
    {
        [Key]
        public int LoanProductId { get; set; }

        [Required]
        public string ProductName { get; set; }

        public decimal InterestRate { get; set; }

        public decimal MinAmount { get; set; }

        public decimal MaxAmount { get; set; }

        public int Tenure { get; set; } // in months

        public ICollection<LoanApplication> LoanApplications { get; set; }
    }
}
