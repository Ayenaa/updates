﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bank.Models.Entities
{
    public class Customer
    {
        [Key]
        public int CustomerId { get; set; }

        [Required]
        public string Name { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public string Phone { get; set; }

        public string Address { get; set; }

        public string KycStatus { get; set; } // PENDING or VERIFIED

        public ICollection<LoanApplication> LoanApplications { get; set; }
    }
}
