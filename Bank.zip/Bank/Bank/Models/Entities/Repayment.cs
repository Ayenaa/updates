﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Bank.Models.Entities;

namespace Bank.Models.Entities
{
    public class Repayment
    {
        [Key]
        public int RepaymentId { get; set; }

        [ForeignKey("LoanApplication")]
        public int ApplicationId { get; set; }

        public DateTime DueDate { get; set; }

        public decimal AmountDue { get; set; }

        public DateTime? PaymentDate { get; set; }

        public string PaymentStatus { get; set; } // PENDING or COMPLETED

        public LoanApplication LoanApplication { get; set; }
    }
}
