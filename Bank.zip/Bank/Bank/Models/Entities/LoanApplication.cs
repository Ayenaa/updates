﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Bank.Models.Entities;

namespace Bank.Models.Entities
{
    public class LoanApplication
    {
        [Key]
        public int ApplicationId { get; set; }

        [ForeignKey("Customer")]
        public int CustomerId { get; set; }

        [ForeignKey("LoanProduct")]
        public int LoanProductId { get; set; }

        public decimal LoanAmount { get; set; }

        public DateTime ApplicationDate { get; set; }

        public string ApprovalStatus { get; set; } // PENDING, APPROVED, REJECTED

        public Customer Customer { get; set; }

        public LoanProduct LoanProduct { get; set; }

        public ICollection<Repayment> Repayments { get; set; }
    }
}
