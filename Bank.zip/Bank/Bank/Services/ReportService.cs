﻿using Bank.Data;
using Bank.Models;
using Microsoft.EntityFrameworkCore;

namespace Bank.Services
{
    public class ReportService
    {
        private readonly BankContext _context;

        public ReportService(BankContext context)
        {
            _context = context;
        }

        public List<LoanReport> GenerateLoanReport()
        {
            return _context.LoanApplications
                .Include(l => l.Customer)
                .Include(l => l.LoanProduct)
                .Select(l => new LoanReport
                {
                    ApplicationId = l.ApplicationId,
                    CustomerName = l.Customer.Name,
                    LoanType = l.LoanProduct.ProductName,
                    LoanAmount = l.LoanAmount,
                    ApplicationDate = l.ApplicationDate,
                    ApprovalStatus = l.ApprovalStatus.ToString()
                }).ToList();
        }

        public List<RepaymentReport> GenerateRepaymentReport()
        {
            return _context.Repayments
                .Include(r => r.LoanApplication)
                .ThenInclude(l => l.Customer)
                .Select(r => new RepaymentReport
                {
                    RepaymentId = r.RepaymentId,
                    CustomerName = r.LoanApplication.Customer.Name,
                    AmountDue = r.AmountDue,
                    DueDate = r.DueDate,
                    PaymentDate = r.PaymentDate,
                    PaymentStatus = r.PaymentStatus.ToString()
                }).ToList();
        }

        public List<OutstandingLoansReport> GenerateOutstandingLoansReport()
        {
            return _context.LoanApplications
                .Include(l => l.Customer)
                .Include(l => l.LoanProduct)
                .Where(l => l.ApprovalStatus == "APPROVED")
                .Select(l => new OutstandingLoansReport
                {
                    ApplicationId = l.ApplicationId,
                    CustomerName = l.Customer.Name,
                    LoanType = l.LoanProduct.ProductName,
                    OutstandingBalance = l.LoanAmount - _context.Repayments
                        .Where(r => r.ApplicationId == l.ApplicationId)
                        .Sum(r => r.AmountDue)
                }).ToList();
        }
    }

}
